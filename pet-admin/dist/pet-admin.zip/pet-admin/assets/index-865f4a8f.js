import{a as e,c,o as n}from"./index-79f9e569.js";const o={},s={class:"menu2-page"};function t(a,r){return n(),c("div",s,"menu2")}const d=e(o,[["render",t]]);export{d as default};
