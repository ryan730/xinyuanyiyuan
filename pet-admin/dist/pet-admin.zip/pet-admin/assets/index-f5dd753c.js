import{a as o,r,b as t,o as n}from"./index-79f9e569.js";const s={name:"ParentView"};function a(c,_,p,i,f,m){const e=r("router-view");return n(),t(e)}const d=o(s,[["render",a]]);export{d as default};
