const l=["large","default","small"],e=[{label:"简体中文",value:"zh-cn"},{label:"English",value:"en"}];export{l as c,e as i};
