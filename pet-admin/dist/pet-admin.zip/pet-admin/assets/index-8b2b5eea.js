import{d as e,u as o,c as n,o as t}from"./index-79f9e569.js";const u=e({__name:"index",setup(s){return console.log(o()),(a,c)=>(t(),n("div",null,"menu-1-1"))}});export{u as default};
