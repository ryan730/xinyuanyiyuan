import{d as e,c as n,o}from"./index-79f9e569.js";const r=e({__name:"index",setup(t){return console.log("index.ts"),(c,s)=>(o(),n("div",null,"首页"))}});export{r as default};
