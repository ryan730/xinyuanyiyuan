import{a as e,c,o as n}from"./index-79f9e569.js";const o={};function r(t,a){return n(),c("div",null,"menu-1-2")}const _=e(o,[["render",r]]);export{_ as default};
